export function sync<T = unknown>(filePath: string): T

export default function readYamlFile<T = unknown>(filePath: string): Promise<T>
