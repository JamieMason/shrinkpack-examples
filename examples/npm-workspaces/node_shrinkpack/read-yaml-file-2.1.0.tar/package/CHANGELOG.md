# read-yaml-file

## 2.1.0

### Minor Changes

- bba9985: graceful-fs and mz removed from dependencies.

## 2.0.1

### Patch Changes

- 68010ea: Use util.promisify instead of the pify library.
- 5f01634: Update js-yaml to version 4.
