# 2.1.0

## TypeScript types

- Add [TypeScript definitions](src/main.d.ts)

# 2.0.0

## Breaking changes

- Minimal supported Node.js version is now `10.17.0`
