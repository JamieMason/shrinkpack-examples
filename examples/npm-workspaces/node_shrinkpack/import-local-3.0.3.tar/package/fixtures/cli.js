#!/usr/bin/env node
'use strict';
const importLocal = require('..');

if (importLocal(__filename)) {
	console.log('local');
}
