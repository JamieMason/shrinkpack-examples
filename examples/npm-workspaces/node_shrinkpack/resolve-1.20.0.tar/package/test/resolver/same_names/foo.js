module.exports = 42;
