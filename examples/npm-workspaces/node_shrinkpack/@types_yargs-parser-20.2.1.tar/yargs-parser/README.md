# Installation
> `npm install --save @types/yargs-parser`

# Summary
This package contains type definitions for yargs-parser (https://github.com/yargs/yargs-parser#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/yargs-parser.

### Additional Details
 * Last updated: Fri, 02 Jul 2021 16:32:07 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Miles Johnson](https://github.com/milesj).
