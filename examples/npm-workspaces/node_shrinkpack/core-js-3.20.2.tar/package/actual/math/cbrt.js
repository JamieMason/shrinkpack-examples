var parent = require('../../stable/math/cbrt');

module.exports = parent;
