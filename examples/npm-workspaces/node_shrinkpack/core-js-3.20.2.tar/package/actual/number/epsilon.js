var parent = require('../../stable/number/epsilon');

module.exports = parent;
