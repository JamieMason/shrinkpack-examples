var parent = require('../../stable/typed-array/copy-within');

module.exports = parent;
