var parent = require('../../../stable/string/virtual/at');

module.exports = parent;
