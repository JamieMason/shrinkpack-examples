var parent = require('../../../stable/string/virtual/code-point-at');

module.exports = parent;
