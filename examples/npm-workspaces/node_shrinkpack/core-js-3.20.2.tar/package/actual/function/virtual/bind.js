var parent = require('../../../stable/function/virtual/bind');

module.exports = parent;
