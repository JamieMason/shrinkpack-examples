var parent = require('../../stable/regexp/constructor');

module.exports = parent;
