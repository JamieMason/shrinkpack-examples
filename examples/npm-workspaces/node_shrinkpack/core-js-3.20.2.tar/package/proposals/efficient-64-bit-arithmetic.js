// TODO: remove from `core-js@4` as withdrawn
// https://gist.github.com/BrendanEich/4294d5c212a6d2254703
require('../modules/esnext.math.iaddh');
require('../modules/esnext.math.isubh');
require('../modules/esnext.math.imulh');
require('../modules/esnext.math.umulh');
