var parent = require('../../actual/instance/code-point-at');

module.exports = parent;
