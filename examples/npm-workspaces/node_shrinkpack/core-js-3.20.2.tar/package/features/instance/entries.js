var parent = require('../../actual/instance/entries');

module.exports = parent;
