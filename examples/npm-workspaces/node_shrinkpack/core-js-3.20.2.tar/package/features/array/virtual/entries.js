var parent = require('../../../actual/array/virtual/entries');

module.exports = parent;
