var parent = require('../../actual/reflect/define-property');

module.exports = parent;
