var parent = require('../../actual/math/asinh');

module.exports = parent;
