var parent = require('../../actual/function/bind');

module.exports = parent;
