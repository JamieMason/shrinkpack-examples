var parent = require('../../../actual/function/virtual/bind');

module.exports = parent;
