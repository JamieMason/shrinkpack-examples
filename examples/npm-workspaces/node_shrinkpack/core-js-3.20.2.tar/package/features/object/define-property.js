var parent = require('../../actual/object/define-property');

module.exports = parent;
