var parent = require('../../actual/object/entries');

module.exports = parent;
