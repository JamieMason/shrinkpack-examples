var parent = require('../../../actual/string/virtual/anchor');

module.exports = parent;
