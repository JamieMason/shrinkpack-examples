require('../../modules/es.weak-set');
require('../../modules/esnext.weak-set.add-all');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('WeakSet', 'addAll');
