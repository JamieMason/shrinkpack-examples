// TODO: Remove this entry from `core-js@4`
require('../proposals/accessible-object-hasownproperty');
// require('../proposals/error-cause');
require('../proposals/global-this');
require('../proposals/promise-all-settled');
require('../proposals/promise-any');
require('../proposals/relative-indexing-method');
require('../proposals/string-match-all');
require('../proposals/string-replace-all');
var path = require('../internals/path');

module.exports = path;
