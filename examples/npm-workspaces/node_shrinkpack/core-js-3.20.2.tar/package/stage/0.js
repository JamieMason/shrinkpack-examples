require('../proposals/efficient-64-bit-arithmetic');
require('../proposals/function-is-callable-is-constructor');
require('../proposals/function-un-this');
require('../proposals/string-at');
require('../proposals/url');
var parent = require('./1');

module.exports = parent;
