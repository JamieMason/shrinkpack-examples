require('../proposals/array-find-from-last');
require('../proposals/array-grouping');
var parent = require('./4');

module.exports = parent;
