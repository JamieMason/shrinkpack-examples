var parent = require('../../es/array/at');

module.exports = parent;
