var parent = require('../../../es/array/virtual/at');

module.exports = parent;
