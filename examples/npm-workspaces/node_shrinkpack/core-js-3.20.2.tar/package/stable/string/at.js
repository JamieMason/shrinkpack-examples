var parent = require('../../es/string/at');

module.exports = parent;
