var parent = require('../../es/regexp/dot-all');

module.exports = parent;
