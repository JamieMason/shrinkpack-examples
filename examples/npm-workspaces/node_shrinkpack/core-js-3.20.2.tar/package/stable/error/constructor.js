var parent = require('../../es/error/constructor');

module.exports = parent;
