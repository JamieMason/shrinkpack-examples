# Installation
> `npm install --save @types/babel__traverse`

# Summary
This package contains type definitions for @babel/traverse (https://github.com/babel/babel/tree/main/packages/babel-traverse).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/babel__traverse.

### Additional Details
 * Last updated: Thu, 08 Jul 2021 14:22:27 GMT
 * Dependencies: [@types/babel__types](https://npmjs.com/package/@types/babel__types)
 * Global values: none

# Credits
These definitions were written by [Troy Gerwien](https://github.com/yortus), [Marvin Hagemeister](https://github.com/marvinhagemeister), [Ryan Petrich](https://github.com/rpetrich), [Melvin Groenhoff](https://github.com/mgroenhoff), [Dean L.](https://github.com/dlgrit), [Ifiok Jr.](https://github.com/ifiokjr), [ExE Boss](https://github.com/ExE-Boss), and [Daniel Tschinder](https://github.com/danez).
