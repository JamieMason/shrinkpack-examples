import { JSONHydrator } from './postcss.js'

declare const fromJSON: JSONHydrator

export default fromJSON
