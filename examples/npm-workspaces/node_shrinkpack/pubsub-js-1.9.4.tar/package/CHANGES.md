# Changes

## 1.9.4

- [`ae3284d`](https://github.com/mroderick/PubSubJS/commit/ae3284d46054b189e143b405e1bfc6c09643bf77)
  Use existing root.pubSub when present (#213) (abishek-srinivasan)
    >
    > This means that loading `pubsub-js` more than once in the same environment will work as the author expects. A warning will be output on the console to make the developer aware of the duplication.

_Released on 2021-11-11._

## 1.9.3

- [`a810919`](https://github.com/mroderick/PubSubJS/commit/a81091962dd4836da9da6dcf7aafeca4aeb9f815)
  Fix countSubscriptions
    >
    > This was introduced in ad93491c760ebc0429a7e9072b2747b2c2ce0a0a, but had
    > a bug that was not covered by unit tests.
    >

_Released on 2021-02-18._

## 1.9.2

- [`83648dd`](https://github.com/mroderick/PubSubJS/commit/83648dd9e48762a8058904debe1b653850bbcf5c)
  fix #115 don't directly use hasOwnProperty (jianghaoran)

_Released on 2020-12-14._

## 1.9.1

- [`ead7906`](https://github.com/mroderick/PubSubJS/commit/ead79069b79df8c4f7d3324047cdb3b9d4c33571)
  Fix amd module export (#173) (Sven Busse)
    >
    > Co-authored-by: Kevin <58685946+Kepeters@users.noreply.github.com>

_Released on 2020-11-13._

## 1.9.0

- [`3fb21e3`](https://github.com/mroderick/PubSubJS/commit/3fb21e309f8bb9fd32906b25b3a607bc32e8b1a7)
  Add `subscribeAll` method (Subin Varghese)

_Released on 2020-08-17._

## 1.8.0

* Add `getSubscriptions`
* Add countSubscriptions

_Released on 2019-12-20._
